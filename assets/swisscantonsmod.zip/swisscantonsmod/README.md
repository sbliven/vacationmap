# A Modified Shapefile for Plotting Swiss Cantons

These files are a modified shapefile for the Swiss cantons. The original shapefile is from GADM (<http://gadm.org/>), which is "freely available for academic use and other non-commercial use".

The modifications are to fix cantonal boundaries that extended beyond the national boundary, especially with regard to lakes.

See <http://druedin.com/2015/11/21/a-modified-shapefile-for-plotting-swiss-cantons/> for more details.
